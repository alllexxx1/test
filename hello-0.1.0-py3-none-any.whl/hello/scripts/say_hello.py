from colorama import Fore, Style


def main(): 
    print(Fore.RED + Style.BRIGHT + 'Hello')


if __name__ == '__main__':
    main()


